import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { ProductService } from './product.service';
import { FirstChildComponent } from './first-child/first-child.component';
import { SecondChildComponent } from './second-child/second-child.component';

@NgModule({
  declarations: [
    AppComponent,
    FirstChildComponent,
    SecondChildComponent
  ],
  imports: [
    BrowserModule
  ],
  // The service is not registered in the providers 
  // array here or in any of the components.
  // This means the service itself must register 
  // itself as a dependency.
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
