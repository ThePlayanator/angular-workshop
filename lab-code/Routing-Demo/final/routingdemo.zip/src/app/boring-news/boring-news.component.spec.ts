import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BoringNewsComponent } from './boring-news.component';

describe('BoringNewsComponent', () => {
  let component: BoringNewsComponent;
  let fixture: ComponentFixture<BoringNewsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [BoringNewsComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(BoringNewsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
