import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ExcitingNewsComponent } from './exciting-news.component';

describe('ExcitingNewsComponent', () => {
  let component: ExcitingNewsComponent;
  let fixture: ComponentFixture<ExcitingNewsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ExcitingNewsComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(ExcitingNewsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
